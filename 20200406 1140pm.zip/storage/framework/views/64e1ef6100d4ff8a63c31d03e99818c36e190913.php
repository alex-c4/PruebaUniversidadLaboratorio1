<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<hr/>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
   
    <div class="section-header">
      <h3>Tabla de Posiciones XportGames </h3>
      <p> listado de puntuaciones por pronostico </p>
    </div>
      
    <div class="container">
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <?php $__currentLoopData = $quinielas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $quiniela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item">
            <a class="nav-link <?php if($key == 0): ?> active <?php endif; ?>" id="nav-<?php echo e($quiniela->id_quiniela); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($quiniela->id_quiniela); ?>" role="tab" aria-controls="nav-<?php echo e($quiniela->id_quiniela); ?>" aria-selected="true"><?php echo e($quiniela->quiniela); ?></a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <div class="tab-content" id="myTabContent">
        <?php $__currentLoopData = $quinielas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $quiniela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="tab-pane fade show <?php if($key2 == 0): ?> active <?php endif; ?>" id="nav-<?php echo e($quiniela->id_quiniela); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($quiniela->id_quiniela); ?>-tab">
            <!-- tabla de puntuacion -->
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Participantes</th>
                    <th scope="col">Puntuacion</th>
                    <th scope="col">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                <?php ($count=0); ?>
                  <?php $__currentLoopData = $listaPuntuaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($participante->id_quiniela==$quiniela->id_quiniela): ?>
                      <tr>
                        <th scope="row"><?php echo e(++$count); ?></th>
                        <td><?php echo e(ucfirst($participante->name)); ?> <?php echo e(ucfirst($participante->lastName)); ?></td>
                        <td><?php echo e($participante->puntos); ?></td>
                        <td><button type="button" class="btn btn-primary"><i class="fa fa-eye"></i></button></td>
                      </tr>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <div class="tab-pane fade" id="nav-4" role="tabpanel" aria-labelledby="nav-4-tab">profile...</div> -->
      </div>
    </div>





    

  </section>

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>