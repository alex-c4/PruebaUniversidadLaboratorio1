<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>


<hr/>
<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
<div style='padding: 50px;'>
    <div class="section-header">
        <h3>RESULTADOS</h3>
        
    </div>
    <div>
        <div class="alert alert-success" role="alert">
            <div class="form-group col-md-12 text-center">
                <p>Resultado de juego realizado con exito...</p>
            </div>
            <hr>
            <div class="form-group col-md-12 text-center">
                <a class="btn btn-primary" href="<?php echo e(route('result.listChampionships')); ?>">Cargar más resultados</a>
            </div>
            
        </div>
    </div>  
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>