<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<br>

<section id="contact" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" style="visibility: hidden" >
    <div class="container" >
        <div class="section-header">
            <br>
            <h3>Registro</h3>
            <p>Registro de Blogs XportGold</p>
        </div>

        <form action="<?php echo e(route('quiniela.addCode')); ?>" method="post" id="form_add_code" >
            <?php echo e(csrf_field()); ?>


            <div class="form-row" >
                <div class="form-group col-md-3">
                </div>

                <div class="form-group col-md-6">
                <label for="codigo">Código<span style="color: red">*</span></label>
                <input type="text" class="form-control <?php echo e($errors->has('codigo') ? 'border-danger' : ''); ?>" name="codigo" id="codigo" placeholder="Código" value="<?php echo e(old('codigo')); ?>">
                <?php echo $errors->first('codigo', '<span class="text-danger">:message</span>'); ?>

                </div>

                <div class="form-group col-md-3">
                </div>


            </div>

            <!-- Boton Aceptar -->
            <div class="text-center">
                <button type="submit" id="btnAceptar" class="btn btn-success">Registrar</button>
            </div>
        </form>




    </div>
</section>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>