<?php $__env->startSection('content'); ?>
<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>


<style type="text/css">
#header{
  background: rgba(0, 0, 0, 0.9);
}
#espaciador{
  margin-top: 10%;
}
  

</style>
<hr/>    
  <section id="contact" style="background: #f7f7f7; visibility: hidden" class="<?php echo e(env('EFECT_WOW')); ?>">  
   
    <div class="section-header">
      <h3>Tabla de Posiciones XportGames </h3>
      <p> listado de puntuaciones por pronostico </p>
    </div>


      
    <div class="container">
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
        </li>
      </ul>
      <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">home...</div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">profile...</div>
      </div>
    </div>





    <div class="row oscuro ">
            <div class="col-lg-6 oscuro-links"> 
             
            <h4 class="text-center"><?php echo e($quiniela->nombre." "." **GOLD**"); ?> </h4>
              <!--<p>Total Pronosticos registrados:<span class="vinculogris"><i class="fa"><?php echo e(count($puntuaciones)); ?></i></span></p>-->
              <ul>
                <?php $__currentLoopData = $puntuaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puntuacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                       
                  <li>
                    <i class="ion-ios-arrow-right"></i>
                    <a href="<?php echo e(route('pronosticGet',['betId'=>$puntuacion->bet_id])); ?>"><?php echo e($puntuacion->name." ".$puntuacion->lastName ."  - Pronostico Nro: ". $puntuacion->bet_id); ?></a>
                    - Total: <strong class="textGold"><?php echo e($puntuacion->puntos); ?></strong> Ptos.                        
                  
                  </li>    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <!--bloque dos de datos...
            se puede eliminar cuando se muestre una solo listado de posiciones porquuiniela-->
            <div class="col-lg-6 oscuro-links"> 
             
              <h4 class="text-center"><?php echo e($quiniela->nombre." "." **FREE**"); ?> </h4>
              <!--<p>Total Pronosticos registrados:<span class="vinculogris"><i class="fa"><?php echo e(count($puntuaciones2)); ?></i></span></p>--></span></p>
              <ul>
                <?php $__currentLoopData = $puntuaciones2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puntuacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                       
                  <li>
                    <i class="ion-ios-arrow-right"></i>
                    <a href="<?php echo e(route('pronosticGet',['betId'=>$puntuacion->bet_id])); ?>"><?php echo e($puntuacion->name." ".$puntuacion->lastName ."  - Pronostico Nro: ". $puntuacion->bet_id); ?></a>
                    - Total: <strong class="textGold"><?php echo e($puntuacion->puntos); ?></strong> Ptos.                        
                  
                  </li>    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>

            <!-- fin bloque dos dedatos-->
          </div>
        </div>

  </section>

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>