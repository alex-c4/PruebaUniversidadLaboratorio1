<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("championship").style.visibility = "visible";
    });
</script>

<div class="separadorHeader"></div>

<section id="championship" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
    <div class="container" >
        <div class="section-header">
            <br>
            <h3>Campeonatos XportGold</h3>
            <p>
                <a href="<?php echo e(route('championship.create')); ?>" title="Agregar de Campeonatos" class="btn btn-outline-success"><i class="fa fa-plus"></i></a>
                <a href="<?php echo e(route('games.create')); ?>" title="Agregar Juegos" class="btn btn-outline-success"><i class="fa fa-mail-forward"></i></a>
            </p>
        </div>

        <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Estatus</th>
                <th scope="col">Nombre</th>
                <th scope="col">Fecha de Inicio</th>
                <th scope="col">Fecha de creación</th>
                <th scope="col" colspan="2">&nbsp;</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $championships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $championship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr scope="row" 
                <?php if($championship->isActive == 0): ?> {
                    class="table-danger"
                }<?php elseif($championship->isActive == 2): ?>{ 
                    class="table-info"
                }<?php else: ?>{
                    class="table-success"
                } 
                <?php endif; ?> >
                <td ><?php echo e($championship->id); ?></td>
                <td ><?php echo e($listStatus[$championship->isActive]["value"]); ?></td>
                <td ><?php echo e($championship->name); ?></td>
                <td ><?php echo e($championship->start_datetime); ?></td>
                <td ><?php echo e($championship->updated_at); ?></td>
                <td>
                    <a href="<?php echo e(route('championship.edit', $championship->id)); ?>" title="Editar" data-toggle="tooltip" data-placement="left" class="btn btn-primary"><i class="fa fa-edit"></i></a>
                </td>
                <td colspan="2">
                    <?php if($championship->isActive == 0): ?>
                        <form id="formRestore_<?php echo e($championship->id); ?>" action="<?php echo e(route('championship.restore', $championship->id)); ?>" method="post" style="margin-bottom: 0px;">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <a href="#" onclick="confirmar(true, <?php echo e($championship->id); ?>)" title="Activar" class="btn btn-light"><i class="fa fa-undo"></i></a>
                        </form>
                    <?php elseif($championship->isActive == 2): ?>
                        <form id="formRestore_<?php echo e($championship->id); ?>" action="<?php echo e(route('championship.restore', $championship->id)); ?>" method="post" style="margin-bottom: 0px;">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <a href="#" onclick="confirmar(true, <?php echo e($championship->id); ?>)" title="Activar" class="btn btn-success"><i class="fa fa-check"></i></a>
                        </form>
                    <?php else: ?>
                        <form id="formDestroy_<?php echo e($championship->id); ?>" action="<?php echo e(route('championship.destroy', $championship->id)); ?>" method="post"style="margin-bottom: 0px;">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <a href="#" onclick="confirmar(false, <?php echo e($championship->id); ?>)" title="Suspender" class="btn btn-danger" title="Suspender"><i class="fa fa-eye-slash"></i></a>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div> 
</section>
<script>
    var confirmar = function(activar, id){
        var msg;
        var form;
        msg = (activar) ? "Por favor confirmar si ud desea activar el Campeonato" : "Por favor confirmar si ud desea desactivar el Campeonato"
        form = (activar) ? "formRestore_" + id : "formDestroy_" + id;
        
        $.confirm({
        title: 'Confirmar',
        content: msg,
        type: 'dark',
        columnClass: 'col-md-6',
        animationBounce: 2.5,
        buttons: {
            confirm: {
                text: 'Si',
                btnClass: 'btn-blue',
                action: function(){
                    document.getElementById(form).submit()
                }
            },
            cancel: {
                text: 'No',
                // action: function(){
                //     $.alert('Cancelado!')
                // }
            }
        }
    });
    }
</script>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>