<?php $__env->startSection('content'); ?>


<hr/>
<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >

    <div class="container" >
        <div style='padding: 50px;'>
            <div class="section-header">
                <h3>Login</h3>
                <p>Ingrese su clave para comenzar el proceso de canje de cromos.</p>
            </div>

            <form method="POST" id="form" action="">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="form-group col-md-3">&nbsp;</div>
                    <!-- COrreo -->
                    <div class="form-group col-md-6">
                        <label for="email">Correo electrónico</label>
                        <input type="email" class="form-control <?php echo e($errors->has('email') ? 'border-danger' : ''); ?>" name="email" id="email" placeholder="Correo electrónico" value="">
                        <?php echo $errors->first('email', '<span class="text-danger">:message</span>'); ?>

                    </div>
                    <div class="form-group col-md-3">&nbsp;</div>
                </div>

                <!-- Boton Aceptar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success form-group">Restablecer</button>
                </div>
            </form>


        </div>
    </div>
        
    
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>