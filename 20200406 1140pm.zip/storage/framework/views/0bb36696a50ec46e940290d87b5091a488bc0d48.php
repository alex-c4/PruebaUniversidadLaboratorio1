<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<hr/>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
    <div class="container" >
        <div class="section-header">
            <br>
            <h3>Listado</h3>
            <p>Clubes XportGold</p>
        </div>

        <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Pais</th>
                <th scope="col">Nombre</th>
                <th scope="col">Logo</th>
                <th scope="col" colspan="2"></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr >
                <th scope="row"><?php echo e($club->id_club); ?></th>
                <td><img src="<?php echo e(url('img/banderas')); ?>/<?php echo e($club->imagen_bandera); ?>" class="" style="width: 25px !important"> </td>
                <td ><a href="#" title="Ver club"><?php echo e($club->nombre); ?></a></td>
                <td><?php echo e($club->imagen_logo); ?></td>
                <td>
                    <a href="#" title="Editar Club" data-toggle="tooltip" data-placement="left" class="btn btn-outline-success"><i class="fa fa-edit"></i></a>
                </td>
                <td>
                    <a href="#" title="Ver Club" class="btn btn-outline-info"><i class="fa fa-eye"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div> 
</section>


    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>