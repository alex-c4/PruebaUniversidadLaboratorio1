<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("championship").style.visibility = "visible";
    });
</script>

<hr/>

<br>

<section id="championship" style="visibility: hidden; margin-top: 20px" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
    <div class="container" >
        <div class="section-header">
            <br>
            <h3>Edición Campeonato</h3>
            <p>
                <a href="<?php echo e(route('championship.index')); ?>" title="Lista de Campeonatos" class="btn btn-outline-primary"><i class="fa fa-list-alt"></i></a>
            </p>
        </div>

        <form action="<?php echo e(route('championship.update', $championship->id)); ?>" method="post" id="form_edit_championship" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

            <?php echo e(csrf_field()); ?>



            <div class="form-row" >
                <!-- Name -->
                <div class="form-group col-md-12">
                    <label for="name">Name <span style="color: red">*</span></label>
                    <input type="text" class="form-control <?php echo e($errors->has('title') ? 'border-danger' : ''); ?>" name="name" id="name" placeholder="Name" value="<?php echo e($championship->name); ?>">
                    <?php echo $errors->first('name', '<span class="text-danger">:message</span>'); ?>

                </div>

                <!-- Fecha de Inicio -->
                <div class="form-group col-md-4">
                <label for="startdate">Fecha de Inicio</label>
                <div class="input-group date dp-date">
                    <input type="text" class="form-control <?php echo e($errors->has('startdate') ? 'border-danger' : ''); ?>" name="startdate" id="startdate" value="<?php echo e($startdate); ?>" >
                    <?php echo $errors->first('startdate', '<span class="text-danger">:message</span>'); ?>

                    <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
                </div>
                </div>

                <!-- Hora -->
                <div class="form-group col-md-4">
                <label for="time">Hora de Inicio <span style="color: red">*</span></label>
                <input type="text" class="form-control <?php echo e($errors->has('time') ? 'border-danger' : ''); ?>" name="time" id="time" placeholder="23:59:59" value="<?php echo e($time); ?>">
                <?php echo $errors->first('time', '<span class="text-danger">:message</span>'); ?>

                </div>


                <!-- Status -->
                <div class="form-group col-md-4">
                <label for="country_id">Estatus <span style="color: red">*</span></label>
                <select class="custom-select <?php echo e($errors->has('status') ? 'border-danger' : ''); ?>" id="status" name="status" >
                    
                    <?php $__currentLoopData = $listStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($championship->isActive == $status['id']): ?>{
                            <option selected value="<?php echo e($status['id']); ?>"><?php echo e($status['value']); ?></option>
                        }<?php else: ?>{
                            <option value="<?php echo e($status['id']); ?>"><?php echo e($status['value']); ?></option>
                        }
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </select>

                <?php echo $errors->first('status', '<span class="text-danger">:message</span>'); ?>

                </div>

            </div>
            
            <!-- Boton Aceptar -->
            <div class="text-center">
                <button type="submit" id="btnAceptar" class="btn btn-success">Registrar</button>
            </div>

        </form>


    </div>
    
</section>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>