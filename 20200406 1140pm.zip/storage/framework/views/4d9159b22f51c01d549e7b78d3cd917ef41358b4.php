<?php $__env->startSection('content'); ?>


<hr/>
<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
        document.getElementById("btnLogin").style.display = "none";
        document.getElementById("passwordLogin").focus()
    });
</script>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >

    <div class="container" >
        <div style='padding: 50px;'>
            <div class="section-header">
                <h3><?php echo e($titulo); ?></h3>
                <p><?php echo e($subtitulo); ?></p>
            </div>

            <form method="POST" id="form" action="<?php echo e(route('auth.loginExternal')); ?>">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="hUrl" value="<?php echo e($url); ?>">

                <div class="row">

                    <?php if($errors->any()): ?>
                        <div class="form-group col-md-3">&nbsp;</div>
                            <div class="alert alert-warning col-md-6" role="alert">
                                <?php echo e($errors->first()); ?>

                            </div>
                        <div class="form-group col-md-3">&nbsp;</div>
                    <?php endif; ?>


                    <div class="form-group col-md-3">&nbsp;</div>
                        <!-- Correo -->
                        <div class="form-group col-md-6">
                            <label for="emailLogin">Correo electrónico</label>
                            <input type="email" class="form-control <?php echo e($errors->has('emailLogin') ? 'border-danger' : ''); ?>" name="emailLogin" id="emailLogin" placeholder="Correo electrónico" value="<?php echo e($email); ?>">
                        </div>
                    <div class="form-group col-md-3">&nbsp;</div>

                    <div class="form-group col-md-3">&nbsp;</div>
                        <!-- Clave -->
                        <div class="form-group col-md-6">
                            <label for="passwordLogin">Clave</label>
                            <input type="password" class="form-control <?php echo e($errors->has('passwordLogin') ? 'border-danger' : ''); ?>" name="passwordLogin" id="passwordLogin"  >
                        </div>
                    <div class="form-group col-md-3">&nbsp;</div>

                </div>

                <!-- Boton Aceptar -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success form-group">Aceptar</button>
                </div>
            </form>


        </div>
    </div>
        
    
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>