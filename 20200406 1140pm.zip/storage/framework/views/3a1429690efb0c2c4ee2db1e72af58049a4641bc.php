<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<hr/>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
    <div class="container" >
        <div class="section-header">
            <br>
            <h3>Listado</h3>
            <p>Campeonatos/Jornadas/Copa</p>
        </div>

        <form method="POST" action="<?php echo e(route('result.index')); ?>">

        <?php echo e(csrf_field()); ?>


        <div class="form-row">
            <!-- Combo de campeonatos -->
            <div class="form-group col-md-12">
              <label for="id_championship">Campeonatos</label>
              <select class="custom-select <?php echo e($errors->has('id_championship') ? 'border-danger' : ''); ?>" id="id_championship" name="id_championship">
                <?php $__currentLoopData = $championships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $championship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($championship->id); ?>"><?php echo e($championship->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              </select>

              <?php echo $errors->first('id_championship', '<span class="text-danger">:message</span>'); ?>

            </div>

            

            <!-- Boton Aceptar -->
            <div class="form-group col-md-12 text-center">
              <button type="submit" class="btn btn-success">Buscar</button>
            </div>
          </div>

        </form>

    </div> 
</section>


    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>