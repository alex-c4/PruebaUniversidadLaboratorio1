<?php $__env->startSection('content'); ?>

<script>
     $(document).ready(function () {
        document.getElementById("contact").style.visibility = "visible";
    });
</script>

<hr/>

<section id="contact" style="visibility: hidden" class="section-bg <?php echo e(env('EFECT_WOW')); ?>" >
<form method="POST" action="<?php echo e(route('savePronostic')); ?>" id="formAddPronostics">

    <div class="section-header">

        <h3>Registro XportGames</h3>
        
        <p>Panel para la creación y registro de las predicciones de los juegos del campeonato</p>

        <div class="container">

            <div class="row">
                <div class="col-12" id="div-container-quinielaPanel"></div>
            </div>
                
            <div class="section-header">
                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                
                <input type="hidden" name="quiniela_id" id="quiniela_id" value="<?php echo e($info['id_quiniela']); ?>">
                <input type="hidden" name="championship_id" id="championship_id" value="<?php echo e($info['id_championship']); ?>">

                <?php if($showGames == 1): ?>
                    <div class="container">
                        <div class="row align-items-center">

                                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="col-12 text-center font-italic text-info">
                                        <?php echo e($game->date); ?>

                                    </div>
                                    <div class="col-12 text-center font-weight-light">
                                        <span class="text-success"> <?php echo e($game->estadium); ?> </span> <?php if($game->grupo != ""): ?> / <span class="font-weight-bold">Grupo <?php echo e($game->grupo); ?> <?php endif; ?></span>
                                    </div>
                                    <div class="col-4 text-right">
                                        <?php echo e($game->nombre_club_1); ?><img src="<?php echo e(asset('img/banderas/')); ?>/<?php echo e($game->img_club_1); ?>" alt="">
                                    </div>
                                    <div class="col-2">
                                        <input type="number" id="input_<?php echo e($game->id); ?>_1" name="input_<?php echo e($game->id); ?>_1" class="form-control col-sm" max="99" min="0" >
                                    </div>
                                    <div class="col-2">
                                        <input type="number" id="input_<?php echo e($game->id); ?>_2" name="input_<?php echo e($game->id); ?>_2" class="form-control col-sm" max="99" min="0" >
                                    </div>
                                    <div class="col-4">
                                        <img src="<?php echo e(asset('img/banderas/')); ?>/<?php echo e($game->img_club_2); ?>" alt=""><?php echo e($game->nombre_club_2); ?> 
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                        
                    </div>

                    <br>

                    <p><b>Nota</b> se tomaran los goles para el pronostico solo hasta el tiempo de juego mas tiempo reglamentario sin tomar en cuenta los penaltis si aplica.</p>

                    <br>
                    
                    
                    <div class="text-center">
                        <button type="button" id="btnAddPronostic" name="btnAddPronostic" class="btn btn-success">Enviar</button>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Información</h4>
                        <p>El juego ya a comenzado.</p>
                        <hr>
                        <p class="mb-0">¡Lo invitamos a estar atentos a los próximos juegos que estaremos registrando, gracias!</p>
                    </div>
                <?php endif; ?>
                
                        
            </div>
        

        </div

        
    </div>
    
</form>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>