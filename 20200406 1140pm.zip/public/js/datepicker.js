$('.dp-date').datepicker({
    format: "yyyy-mm-dd",
    language: "en",
    autoclose: true,
    startView: 2
});