<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quinielatipo extends Model
{
    //
    protected $table = 'quinielatipo';
}