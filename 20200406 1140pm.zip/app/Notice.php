<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notice extends Model
{
	//tabla asociada con el modelo
	protected $table ='noticias';
    	//
}
